
DBHOST = '127.0.0.1'
DBPORT = 3306
DBUSER = 'root'
DBPWD = '123456'
DBNAME = 'vms'
DBCHAR = 'utf8'